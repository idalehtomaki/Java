package Lehtomaki;

public interface ShapeSpecial {
    
    public double calculateArea();
    public double calculatePerimeter();
    public void drawShape();
}
