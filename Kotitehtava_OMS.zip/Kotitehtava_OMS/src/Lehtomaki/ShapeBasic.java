package Lehtomaki;

public interface ShapeBasic {
    public void draw();
    public void grow();
    public String printText();
    public boolean isVisible();
}
